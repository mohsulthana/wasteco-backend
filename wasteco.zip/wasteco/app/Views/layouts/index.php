<?php
echo view('layouts/header');
echo view('layouts/sidebar');
echo view('layouts/navbar');
echo view($content);
echo view('layouts/footer');