<?php namespace App\Controllers\API;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ChallengeModel;

class Challenge extends ResourceController {

    use ResponseTrait;

    public function index()
    {
        $model = new ChallengeModel();
        $data = $model->findAll();
        return $this->respond($data, 200);
    }
}